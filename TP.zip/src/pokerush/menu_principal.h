#include "pokerush.h"

/**
 * Menú principal de donde se acceden a todas las
 * funciones del juego
*/
struct pr_escena pr_menu_principal();