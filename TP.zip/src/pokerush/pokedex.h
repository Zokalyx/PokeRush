#include "pokerush.h"

/**
 * Listado de todos los pokemones y sus detalles
*/
struct pr_escena pr_pokedex();