#include "pokerush.h"

/**
 * Selección de Pokémon y de obstáculos.
*/
struct pr_escena pr_preparacion();