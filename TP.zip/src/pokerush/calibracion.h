#include "pokerush.h"

/**
 * Calibración de tiempos y tamaño de pantalla.
*/
struct pr_escena pr_calibracion();