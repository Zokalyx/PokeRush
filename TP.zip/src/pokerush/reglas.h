#include "pokerush.h"

/**
 * Cómo se juega
*/
struct pr_escena pr_reglas();