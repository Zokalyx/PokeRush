#include "pokerush.h"

/**
 * Selección de dificultad/oponente
*/
struct pr_escena pr_menu_juego();