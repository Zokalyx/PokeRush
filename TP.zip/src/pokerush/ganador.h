#include "pokerush.h"

/**
 * Pantalla donde se muestra el puntaje
 * y se da la opción de reintentar.
*/
struct pr_escena pr_ganador();