#include "pokerush.h"

/**
 * Personalización del jugador.
*/
struct pr_escena pr_entrenador();