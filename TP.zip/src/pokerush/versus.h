#include "pokerush.h"

/**
 * Animación previa a la carrrera.
*/
struct pr_escena pr_versus();