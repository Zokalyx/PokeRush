#include "pokerush.h"

/**
 * Pantalla inicial del juego con título animado.
*/
struct pr_escena pr_splash_screen();