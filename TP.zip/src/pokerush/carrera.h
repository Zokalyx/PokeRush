#include "pokerush.h"

/**
 * Carrera/Juego en sí. 
*/
struct pr_escena pr_carrera();