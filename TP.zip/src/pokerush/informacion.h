#include "pokerush.h"

/**
 * Información general sobre el juego y su desarrollo
*/
struct pr_escena pr_informacion();